import { LightningElement, api } from 'lwc';
import SUBJECT_FIELD from '@salesforce/schema/Case.Subject';
import CONTACTPHONE_FIELD from '@salesforce/schema/Case.Description';

export default class EditFieldForCaseObj extends LightningElement {

    subjectField = SUBJECT_FIELD;
    descriptionField= CONTACTPHONE_FIELD;

    @api recordId;
    @api objectApiName;

}