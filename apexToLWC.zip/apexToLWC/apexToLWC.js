import { wire, LightningElement  } from 'lwc';
import getContactList from '@salesforce/apex/ContactController.getContactList';

export default class ApexToLWC extends LightningElement {
   /* @wire(getContactList) contacts;*/
}

