function add(){     
    const a= document.getElementById('firstValue').value
    const b= document.getElementById('secondValue').value
    const c = Number(a) + Number(b);
    document.getElementById("demo").innerHTML = 'Result is :'+c
    //alert(a+b+c)
    return c            
}

function subtract(){     
    const a= document.getElementById('firstValue').value
    const b= document.getElementById('secondValue').value
    const c = Number(a) - Number(b);
    document.getElementById("demo").innerHTML = 'Result is :'+c
    //alert(a+b+c)
    return c            
}

function multiplication(){     
    const a= document.getElementById('firstValue').value
    const b= document.getElementById('secondValue').value
    const c = Number(a) * Number(b);
    document.getElementById("demo").innerHTML = 'Result is :'+c
    //alert(a+b+c)
    return c            
}