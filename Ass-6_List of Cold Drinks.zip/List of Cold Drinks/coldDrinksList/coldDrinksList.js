import { LightningElement } from 'lwc';

export default class ColdDrinksList extends LightningElement {}