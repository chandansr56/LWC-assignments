import { LightningElement } from 'lwc';

export default class CocaCola extends LightningElement {

    coldDrinfName = 'COCA COLA';
    ColdDrinkImage = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXc60V2DquraaFR0JIAPr-IK7jB_Ie4lrKMjCZDnxQYd3WbwGL9m-NG9gj1oCNVlVS0Ok&usqp=CAU";
    
}