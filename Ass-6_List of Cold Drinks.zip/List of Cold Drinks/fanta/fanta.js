import { LightningElement } from 'lwc';

export default class Fanta extends LightningElement {

    coldDrinfName = 'FANTA';
    ColdDrinkImage = "https://media.istockphoto.com/id/508584082/photo/fanta-can-on-white.jpg?s=612x612&w=0&k=20&c=obQPF_KvFiSRdfAUAnpMj7DjFebJsPgM0JsLoVtjTqA=";
    
}