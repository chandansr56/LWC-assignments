import { LightningElement } from 'lwc';

export default class ColdDrinksTile extends LightningElement {

    coldDrinfName = 'PEPSI';
    ColdDrinkImage = "https://t4.ftcdn.net/jpg/02/96/15/67/360_F_296156723_tw7WRQTa80yfT3B2LL1fcOKP9jtHRr4B.jpg";
    
}
