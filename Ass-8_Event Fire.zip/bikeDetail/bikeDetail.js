import { api, LightningElement } from 'lwc';

export default class BikeDetail extends LightningElement {
    @api name1
    @api version1
    @api model1
}