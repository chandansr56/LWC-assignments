import {api, LightningElement } from 'lwc';

export default class BikeContainer extends LightningElement {

        @api xx;
        @api yyy;
        @api image;
        @api x1id = '123456';

        bike = {name:"Duke", model:"390cc", version:"v3"};
        //@api image ='https://imgd.aeplcdn.com/600x600/n/cw/ec/129571/v302c-right-front-three-quarter.gif?isig=0';

        eventTrigger(payload){
               console.log(this.bike);
                const event = new CustomEvent('eventhandle' ,{ 
                        bubbles:true,
                        composed:true,                             
                        detail: this.bike                
                });
                this.dispatchEvent(event);
        }
       
}