import { LightningElement } from 'lwc';

export default class BikeList extends LightningElement {

    fireResut = '0';

    x1id = 0;
    xx1 = 'DUKE';
    yyy1 = 'yr2022';
    image1 = 'https://www.drivespark.com/bikes-photos/models/350x220/390-duke_1515499621.jpg/2/x.pagespeed.ic.reQTAzRWEm.jpg'
    
    x2id = 1;
    xx2 = 'KTM';
    yyy2 = 'yr2022';
    image2 = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGB4M2Mp-wTXhCmkPIusK3Io-5nmV18QKtn3RGD2sMKETvkphoohNk_JF7ysbn18SMSAg&usqp=CAU'

    name2 = '';
    version2='';
    model2='';

    eventCatch(payload1){   

    console.log('fired:'+ payload1.detail.name);
    console.log('fired:'+ payload1.detail.model);
    console.log('fired:'+ payload1.detail.version);

    this.name2 = payload1.detail.name;
    this.model2= payload1.detail.model;
    this.version2= payload1.detail.version;
     
    }

    


}