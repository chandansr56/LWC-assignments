import {api, LightningElement } from 'lwc';

export default class BikeContainer extends LightningElement {

        @api xx;
        @api yyy;
        @api image;
        //@api image ='https://imgd.aeplcdn.com/600x600/n/cw/ec/129571/v302c-right-front-three-quarter.gif?isig=0';

}