import { LightningElement } from 'lwc';

export default class FirstLWC extends LightningElement {
    firstName1 = 'First Name'
    lastName1 = 'Last Name'

    handleInputChange(event){
        this.firstName1 = event.target.value;        
    } 

    handleInputChange1(event){        
        this.lastName1 = event.target.value;
    } 
    
}